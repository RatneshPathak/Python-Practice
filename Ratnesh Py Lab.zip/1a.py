a = 5
b = 10
multiplication_result = a * b
sum_result = a + b
print("multiplication:", multiplication_result)
print("Sum:", sum_result)