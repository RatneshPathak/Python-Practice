x = 20
y = 15
largest = x if x > y else y
print("Largest variable:", largest)